To Run the application:
Run the Main.py File
command :
python AyushiShoppingIssueChatbot.py

Developed by:
Ayushi Sharma,
GET, NPCI
