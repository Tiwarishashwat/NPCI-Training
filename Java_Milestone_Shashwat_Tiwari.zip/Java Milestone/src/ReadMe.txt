Hello , Weclome to java Milestone Assessment
The structure of the code contains 3 files namingly:
1. Main:
  a. User Interface and CLI operations along with Exception Handling is present in this class.
  b. This is the Application's Enterance file.

2. Loan:
  a. This is a Loan class cntaining attributes like Customer Name, Age, Loan needs, etc.
  b. This class contains getters and setters.

3. EMICalculator:
  a. This class is a child class of Loan class.
  b. It follows the structure of Inheritance.
  c. This class contains Getters and Setters.
  d. It is responsible for handling all kinds of exception.   

How to Run the code?
1. javac Main.java
2. java Main

Thats it.
All files are linked internally!

Designed and Developed by:
Shashwat Tiwari,
GET, NPCI