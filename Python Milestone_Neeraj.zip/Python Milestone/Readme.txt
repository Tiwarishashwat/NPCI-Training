To Run the application:
Run the Main.py File
command :
python Chatbot.py

Developed by:
Neeraj
GET, NPCI
