Hello,
 below mentioned features have been successfully Added in the chatbot
- Greet customers based on time of day eg: Good morning/afternoon/evening 
- Accept customer name and greet them as "John, I hope you're doing well" 
- Ask customer if they have a ticket number or want to raise new concern 
- On existing ticket update them the status if it is closed 
- Otherwise assure them of resolving the issues 
- On new concern read a JSON file for the customers product they ordered 
- Ask them to choose a product regarding which they have concerns 
- On selection of product, provide them with common options 
- Delayed Shipping - Damage Product Delivered 
- Return/Replacement 
- On selection of the option ask them to provide brief description 
- Save details into a file with new generated ticket number 
- Greet them good bye with assurance of assistance

To Run the application:
Run the Main.py File
command :
python Main.py

Designed and Developed by:
Shashwat Tiwari,
GET, NPCI
